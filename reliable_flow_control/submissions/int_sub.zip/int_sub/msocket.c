#include "msocket.h"

#define wait(s) semop(s, &pop, 1) 
#define signall(s) semop(s, &vop, 1) 

#define SEM_MACRO 5
#define SHM_MACRO 6
#define SEM_MACRO2 7
#define SHM_MACRO2 8

// write a signal handler for ctrl c
void sighandler (int signum) {
    int shm_sockhand = shmget(ftok("msocket.h", SHM_MACRO), MAXSOCKETS*sizeof(struct m_socket_handler), 0777 | IPC_CREAT);
    shmctl(shm_sockhand, IPC_RMID, NULL);
    int sem_join = semget(ftok("msocket.h", SEM_MACRO), MAXSOCKETS, 0777 | IPC_CREAT);
    semctl(sem_join, 0, IPC_RMID);
    exit(0);
}


int m_recvfrom (int sockfd, void *buf, size_t len) {
    signal(SIGINT, sighandler);
    int sem_join = semget(ftok("msocket.h", SEM_MACRO), MAXSOCKETS, 0777 | IPC_CREAT);
    struct sembuf pop, vop;
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1; vop.sem_op = 1;
    int shm_sockhand = shmget(ftok("msocket.h", SHM_MACRO), MAXSOCKETS*sizeof(struct m_socket_handler), 0777 | IPC_CREAT);
    struct m_socket_handler* SM = (struct m_socket_handler*)shmat(shm_sockhand, NULL, 0);
    pop.sem_num = vop.sem_num = sockfd;
    wait(sem_join);
    if (SM[sockfd].is_alloted == 1) {
        int j;
        for (j=0; j<RWND; j++){ 
            if (SM[sockfd].rwnd.seq_no[j] == SM[sockfd].recv_seq_no) break;
        }
        if (j < RWND && SM[sockfd].recv_status[j] == 1) {
            strcpy((char*)buf, SM[sockfd].recv_buf[j]);
            SM[sockfd].recv_status[j] = 0;
            SM[sockfd].recv_seq_no = (SM[sockfd].recv_seq_no+1)%MAXSEQNO;
            if (SM[sockfd].recv_seq_no == 0) SM[sockfd].recv_seq_no = 1;
            signall(sem_join);
            pop.sem_num = vop.sem_num = 0;
            return strlen(buf); // ???? what to do if the len is less than the actual len (strlen(buf))
        }
        else {
            signall(sem_join);
            pop.sem_num = vop.sem_num = 0;
            return -1;
        }
    }
    signall(sem_join);
    pop.sem_num = vop.sem_num = 0;
    return -1;
}

int m_sendto(int sockfd, const void *buf, size_t len) {  // ???? what checks for dest ip and port
    signal(SIGINT, sighandler);
    int sem_join = semget(ftok("msocket.h", SEM_MACRO), MAXSOCKETS, 0777 | IPC_CREAT);
    struct sembuf pop, vop;
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1; vop.sem_op = 1;
    int shm_sockhand = shmget(ftok("msocket.h", SHM_MACRO), MAXSOCKETS*sizeof(struct m_socket_handler), 0777 | IPC_CREAT);
    struct m_socket_handler* SM = (struct m_socket_handler*)shmat(shm_sockhand, NULL, 0);
    pop.sem_num = vop.sem_num = sockfd;
    wait(sem_join);
    if (SM[sockfd].is_alloted == 1) {
        int iter = SM[sockfd].swnd_markers[0]; int flag = 0;
        while (SM[sockfd].send_status[iter] != 0 && flag < SWND) {
            flag++;
            iter = (iter+1)%SWND;
        }
        if (SM[sockfd].send_status[iter] == 0) {  
            strcpy(SM[sockfd].send_buf[iter], (char*)buf); // ???? just doing for string bufs for now
            SM[sockfd].swnd.seq_no[iter] = SM[sockfd].send_seq_no;

            SM[sockfd].send_seq_no = (SM[sockfd].send_seq_no+1)%MAXSEQNO;
            if (SM[sockfd].send_seq_no == 0) SM[sockfd].send_seq_no = 1;
            
            SM[sockfd].send_status[iter] = 1;
            signall(sem_join);
            pop.sem_num = vop.sem_num = 0;
            return strlen(buf);
        }
        else {
            signall(sem_join);
            pop.sem_num = vop.sem_num = 0;
            return -1;
        }
    } else {
        signall(sem_join);
        pop.sem_num = vop.sem_num = 0;
        return -1;
    }
}

int m_socket(int domain, int type, int protocol){ 
    signal(SIGINT, sighandler);
    int sem_join = semget(ftok("msocket.h", SEM_MACRO), MAXSOCKETS, 0777 | IPC_CREAT);
    struct sembuf pop, vop;
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1; vop.sem_op = 1;
    int shm_sockhand = shmget(ftok("msocket.h", SHM_MACRO), MAXSOCKETS*sizeof(struct m_socket_handler), 0777 | IPC_CREAT);
    struct m_socket_handler* SM = (struct m_socket_handler*)shmat(shm_sockhand, NULL, 0);
    if (type != SOCK_MTP) return -1;
    if (domain != AF_INET) return -1;
    // if (protocol != 0) return -1; // ???? do we need to check this
    int sem_soc_create = semget(ftok("msocket.h", SEM_MACRO2), 3, 0777 | IPC_CREAT);
    int shm_sock_info = shmget(ftok("msocket.h", SHM_MACRO2), sizeof(struct sock_info), 0777 | IPC_CREAT);
    struct sock_info* sock_info = (struct sock_info*)shmat(shm_sock_info, NULL, 0);
    pop.sem_num = vop.sem_num = 2;
    wait(sem_soc_create);
    pop.sem_num = vop.sem_num = 0;
    signall(sem_soc_create);
    pop.sem_num = vop.sem_num = 1;
    wait(sem_soc_create);
    if (sock_info->err == 1) {
        sock_info->err = 0;
        sock_info->sockfd=0;
        pop.sem_num = vop.sem_num = 2;
        signall(sem_soc_create);
        return -1;
    }
    int i;
    for (i=0; i<MAXSOCKETS; i++){
        pop.sem_num = vop.sem_num = i;
        wait(sem_join);
        if (SM[i].is_alloted == 0) {
            SM[i].is_alloted = 1;
            SM[i].process_id = getpid();
            SM[i].socket_id = sock_info->sockfd;
            signall(sem_join);
            sock_info->sockfd=0;
            pop.sem_num = vop.sem_num = 2;
            signall(sem_soc_create);
            return i;
        }
        signall(sem_join);
        pop.sem_num = vop.sem_num = 0;
    }
    sock_info->sockfd=0;
    pop.sem_num = vop.sem_num = 2;
    signall(sem_soc_create);
    return -1;
}

int m_bind(int sockfd, char* source_ip, int source_port, char* dest_ip, int dest_port){  
    signal(SIGINT, sighandler);
    int sem_join = semget(ftok("msocket.h", SEM_MACRO), MAXSOCKETS, 0777 | IPC_CREAT);
    struct sembuf pop, vop;
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1; vop.sem_op = 1;
    int shm_sockhand = shmget(ftok("msocket.h", SHM_MACRO), MAXSOCKETS*sizeof(struct m_socket_handler), 0777 | IPC_CREAT);
    struct m_socket_handler* SM = (struct m_socket_handler*)shmat(shm_sockhand, NULL, 0);
    int sem_soc_create = semget(ftok("msocket.h", SEM_MACRO2), 3, 0777 | IPC_CREAT);
    int shm_sock_info = shmget(ftok("msocket.h", SHM_MACRO2), sizeof(struct sock_info), 0777 | IPC_CREAT);
    struct sock_info* sock_info = (struct sock_info*)shmat(shm_sock_info, NULL, 0);
    pop.sem_num = vop.sem_num = 2;
    wait(sem_soc_create);
    sock_info->sockfd = sockfd;
    strcpy(sock_info->src_ip, source_ip);
    sock_info->src_port = source_port;
    sock_info->err = 0;
    pop.sem_num = vop.sem_num = 0;
    signall(sem_soc_create);
    pop.sem_num = vop.sem_num = 1;
    wait(sem_soc_create);
    if (sock_info->err == 1) {
        sock_info->err = 0;
        sock_info->sockfd=0;
        sock_info->src_ip[0] = '\0';
        sock_info->src_port = 0;
        pop.sem_num = vop.sem_num = 2;
        signall(sem_soc_create);
        return -1;
    }
    pop.sem_num = vop.sem_num = sockfd;
    wait(sem_join);
    if (SM[sockfd].is_alloted == 1) {
        strcpy(SM[sockfd].src_ip_addr, source_ip);
        SM[sockfd].src_port = source_port;
        strcpy(SM[sockfd].dest_ip_addr, dest_ip);
        SM[sockfd].dest_port = dest_port;
        signall(sem_join);
        pop.sem_num = vop.sem_num = 0;
        sock_info->err = 0;
        sock_info->sockfd=0;
        sock_info->src_ip[0] = '\0';
        sock_info->src_port = 0;  
        pop.sem_num = vop.sem_num = 2;
        signall(sem_soc_create);
        return 0;
    }
    sock_info->err = 0;
    sock_info->sockfd=0;
    sock_info->src_ip[0] = '\0';
    sock_info->src_port = 0;
    pop.sem_num = vop.sem_num = 2;
    signall(sem_soc_create);
}

int m_close(int fd){ 
    signal(SIGINT, sighandler);
    int sem_join = semget(ftok("msocket.h", SEM_MACRO), MAXSOCKETS, 0777 | IPC_CREAT);
    struct sembuf pop, vop;
    pop.sem_num = vop.sem_num = 0;
    pop.sem_flg = vop.sem_flg = 0;
    pop.sem_op = -1; vop.sem_op = 1;
    int sem_soc_create = semget(ftok("msocket.h", SEM_MACRO2), 3, 0777 | IPC_CREAT);
    int shm_sock_info = shmget(ftok("msocket.h", SHM_MACRO2), sizeof(struct sock_info), 0777 | IPC_CREAT);
    struct sock_info* sock_info = (struct sock_info*)shmat(shm_sock_info, NULL, 0);
    int shm_sockhand = shmget(ftok("msocket.h", SHM_MACRO), MAXSOCKETS*sizeof(struct m_socket_handler), 0777 | IPC_CREAT);
    struct m_socket_handler* SM = (struct m_socket_handler*)shmat(shm_sockhand, NULL, 0);
    pop.sem_num = vop.sem_num = 2;
    wait(sem_soc_create);
    sock_info->sockfd = fd;
    sock_info->err = 0;
    pop.sem_num = vop.sem_num = 0;
    signall(sem_soc_create);
    pop.sem_num = vop.sem_num = 1;
    wait(sem_soc_create);
    if (sock_info->err == 1) {
        sock_info->err = 0;
        sock_info->sockfd=0;
        pop.sem_num = vop.sem_num = 2;
        signall(sem_soc_create);
        return -1;
    }
    pop.sem_num = vop.sem_num = fd;
    wait(sem_join);
    if (SM[fd].is_alloted == 1) {
        SM[fd].is_alloted = 0;
        SM[fd].process_id = 0;
        SM[fd].socket_id = 0;
        SM[fd].src_ip_addr[0] = '\0';
        SM[fd].src_port = 0;
        SM[fd].dest_ip_addr[0] = '\0';
        SM[fd].dest_port = 0;
        signall(sem_join);
        pop.sem_num = vop.sem_num = 0;
        sock_info->err = 0;
        sock_info->sockfd=0;
        pop.sem_num = vop.sem_num = 2;
        signall(sem_soc_create);
        return 0;
    }
    sock_info->err = 0;
    sock_info->sockfd=0;
    pop.sem_num = vop.sem_num = 2;
    signall(sem_soc_create);
    return -1;
}

int dropMessage(float pp) { 
    signal(SIGINT, sighandler);
    // generate a random number between 0 and 1
    float m_num = (float)rand()/(float)(RAND_MAX);
    if (m_num < pp) {
        return 1;
    }
    return 0;
}
